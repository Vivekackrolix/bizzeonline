<?php
if(isset($_POST['submit']))
{
	$username=$_POST['name'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$msg=$_POST['message'];
		$to = "subrata@bizzeonline.com";
         $subject = "Contact Form";
         
         $message = "Username : ".$username."<br>Email : ".$email."<br>Phone : ".$phone."<br>Message :".$msg."";     
         
         $header = "From:subrata@bizzeonline.com \r\n";
         $header .= "Cc:subrata@bizzeonline.com\r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         $retval = mail ($to,$subject,$message,$header);
         
        
}

?>

<?php
// Define variables for SEO

$pageTitle = 'Bizzeonline | Mobile App Development Company Gurgaon India |Software Development Company';

$pageDescription = 'Bizzeonline is Mobile App Development Company In Gurgaon: One of the Best Mobile App Development Company Gurgaon India. Ranked among the Top website development company gurgaon';

$pagekeywords = 'Bizzeonline, Bizzeonline, www.Bizzeonline.com, Mobile App Development Company, Mobile App Development Company Gurgaon India, Best Mobile App Development Company Gurgaon India, Mobile App Design Company, Mobile App Design Company Gurgaon, Best Mobile App Design Company gurgaon, Top Mobile App Design Company, Mobile App Designer In Gurgaon, Mobile App Design Company In Gurgaon, Mobile App Development Company Gurgaon, Android Mobile App Development Company, Native Mobile App Development Company In Gurgaon, Android Mobile App Development Company Gurgaon, Best Mobile App Development Company';

$canonicalurl ='https://www.bizzeonline.in/thankyou.php';

$ogtitle = 'Mobile App Design & Development Company Gurgaon India |Mobile App Development Company | Bizzeonline';


$ogdescription= 'Mobile App Development Company Gurgaon: Bizzeonline is one of the Best Mobile App Development Company Gurgaon India. Ranked among the Top Mobile App development company gurgaon';

$ogurl ='https://www.bizzeonline.in/thankyou.php';

$ogsitename ='Bizzeonline | Mobile App Development Company Gurgaon';

$ogimageurl ='';

$ogimagesecureurl = '';

$twdescription = 'Mobile App Development Company Gurgaon: Mobile App is one of the Best Mobile App Design Development Company Gurgaon India. Ranked among the Top Mobile App development company gurgaon';

$twtitle = 'Mobile App Design & Development Company Gurgaon India |Mobile App Development Company | Bizzeonline';

$twimageurl = '';

$schemaidname = ' https://www.bizzeonline.in/thankyou.php\/#breadcrumb,';

$listid = 'https://www.bizzeonline.in/thankyou.php';

$listidname = 'Mobile App Development Company Gurgaon: Mobile App is one of the Best Mobile App Design Development Company Gurgaon India. Ranked among the Top Mobile App development company gurgaon';

$templatename = 'page-template page-template-template-parts page-template-Mobile -App-design-gurgaon page-template-Mobile-App-development-gurgaon page-template-template-parts-Mobile-App-developemnt-company-gurgaon';

?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8">
    <!-- Stylesheets -->
    
<!-- Event snippet for Website lead conversion page --> 
<script> gtag('event', 'conversion', 
{'send_to': 'AW-302520116/yvTqCKfImfMCELSuoJAB'}); 
</script>


    <link href="https://fonts.googleapis.com/css2?family=Teko:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/owl.css" rel="stylesheet">
    <link href="css/flaticon.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/jquery-ui.css" rel="stylesheet">
    <link href="css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="css/hover.css" rel="stylesheet">
    <link href="css/custom-animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- rtl css -->
    <link href="css/rtl.css" rel="stylesheet">
    <!-- Responsive File -->
    <link href="css/responsive.css" rel="stylesheet">

    <!-- Color css -->
    <link rel="stylesheet" id="jssDefault" href="css/colors/color-default.css">

    <link rel="shortcut icon" href="images/favicon.png" id="fav-shortcut" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" id="fav-icon" type="image/x-icon">

    <!-- Responsive Settings -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
    <!-- Event snippet for Contact Form Page conversion page -->
<script>
  gtag('event', 'conversion', {'send_to': 'AW-677970550/naY8CL6f6o0DEPaEpMMC'});
</script>
</head>

<body>
         <!--Error Section-->
        <section class="error-section">
            <div class="auto-container">
                <div class="content">
                    
                    <h2>Than You So Much For Contacting Us!</h2>
                    <div class="text">Our Team will get back to you soon.</div>
                    
                    <div class="link-box">
                        <a class="theme-btn btn-style-one" href="index.php">
                            <i class="btn-curve"></i>
                            <span class="btn-title">Back to home</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>



    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>



    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/TweenMax.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.fancybox.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/mixitup.js"></script>
    <script src="js/knob.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jQuery.style.switcher.min.js"></script>
    <script type="text/javascript" src="../../cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.2/js.cookie.min.js">
    </script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/custom-script.js"></script>


    <script src="js/lang.js"></script>
    <script src="../../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>
    <script src="js/color-switcher.js"></script>

</body>


</html>