 <!-- Main Footer -->
        <footer class="main-footer">
             <div class="call_btn">
    <a href="tel:+918178567042"> Call Now</a>
 </div>
            <div class="auto-container">
                <!--Widgets Section-->
                <div class="widgets-section">
                    <div class="row clearfix">

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget logo-widget">
                                <div class="widget-content">
                                    <div class="logo">
                                        <a href="index.php"><img id="fLogo" src="images/bizzeonline footer logo.png" alt="" /></a>
                                    </div>
                                    <div class="text">Welcome to our website bizzeonline.com website design & development company</div>
                                    <ul class="social-links clearfix">
                                        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                        <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <div class="widget-content">
                                    <h6>Explore</h6>
                                    <div class="row clearfix">
                                        <div class="col-md-6 col-sm-12">
                                            <ul>
                                                <li><a href="index.php">Home</a></li>
                                                <li><a href="about.php">About</a></li>
                                                <li><a href="team.php">Meet Our Team</a></li>
                                                <li><a href="portfolio.php">Our Portfolio</a></li>
                                                
                                                <li><a href="contact.php">Contact</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <ul>
                                                <li><a href="career.php">Career</a></li>
                                                <li><a href="#">Support</a></li>
                                                <li><a href="#">Privacy Policy</a></li>
                                                <li><a href="#">Terms of Use</a></li>
                                                <li><a href="contact.php">Help</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget info-widget">
                                <div class="widget-content">
                                    <h6>Contact</h6>
                                    <ul class="contact-info">
                                        <li class="address"><span class="icon flaticon-pin-1"></span> Sushant Lok Phase 1<br>Gurgaon HR. - 122001 India</li>
                                        <li><span class="icon flaticon-call"></span><a href="tel:+91-8178567042">+91-8178567042</a></li>
                                        <li><span class="icon flaticon-email-2"></span><a
                                                href="mailto:info@bizzeonline.com">info@bizzeonline.com</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget newsletter-widget">
                                <div class="widget-content">
                                    <h6>Newsletter</h6>
                                    <div class="newsletter-form">
                                        <form method="post" action="">
                                            <div class="form-group clearfix">
                                                <input type="email" name="email" value="" placeholder="Email Address"
                                                    required="">
                                                <button type="submit" class="theme-btn"><span
                                                        class="fa fa-envelope"></span></button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="text">Sign up for our latest news & articles. We won’t give you spam
                                        mails.</div>
                                </div>
                            </div>
                        </div>



      <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <div class="widget-content">
                                    <h6>Gurgaon Service Area</h6>
                                    <ul>
                                    
                                                <li><a href="website-design-company-gurgaon.php">Website Design company In Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-4-gurgaon.php">Website Design company In Sector 4 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-9-gurgaon.php">Website Design company In Sector 9 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-10-gurgaon.php">Website Design company In Sector 10 Gurgaon</a></li>
                                                
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-14-gurgaon.php">Website Design company In Sector 14 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-15-gurgaon.php">Website Design company In Sector 15 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-17-gurgaon.php">Website Design company In Sector 17 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-18-gurgaon.php">Website Design company In Sector 18 Gurgaon</a></li>
                                                 <li><a href="https://bizzeonline.com/website-developer-gurgaon.php">Website Developer Gurgaon</a></li>
                                                </ul>
                                               
                                               
                                            
                                </div>
                            </div>
                        </div>


                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <div class="widget-content">
                                    <h6>Gurgaon Service Area</h6>
                                    <ul>
                                    
                                                <li><a href="website-design-company-gurgaon.php">Web Design company In Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-29-gurgaon.php">Website Design company In Sector 29 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-30-gurgaon.php">Website Design company In Sector 30 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-31-gurgaon.php">Website Design company In Sector 31 Gurgaon</a></li>
                                                
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-44-gurgaon.php">Website Design company In Sector 44 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-45-gurgaon.php">Website Design company In Sector 45 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-50-gurgaon.php">Website Design company In Sector 50 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-51-gurgaon.php">Website Design company In Sector 51 Gurgaon</a></li>
                                                
                                                <li><a href="https://bizzeonline.com/website-designer-gurgaon.php">Website Designer Gurgaon</a></li>
                                                </ul>
                                            
                                </div>
                            </div>
                        </div>

                              <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <div class="widget-content">
                                    <h6>Gurgaon Service Area</h6>
                                    
                                            <ul>
                                                <li><a href="website-design-company-gurgaon.php">Website Design company In Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-52-gurgaon.php">Website Design company In Sector 52 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-53-gurgaon.php">Website Design company In Sector 53 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-54-gurgaon.php">Website Design company In Sector 54 Gurgaon</a></li>
                                                
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-55-gurgaon.php">Website Design company In Sector 55 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-56-gurgaon.php">Website Design company In Sector 56 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-60-gurgaon.php">Website Design company In Sector 60 Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sector-61-gurgaon.php">Website Design company In Sector 61 Gurgaon</a></li>
                                          
                                            <li><a href="https://bizzeonline.com/website-developer-near-me.php">Website Developer Near Me</a></li>
                                            </ul>
                                       
                                </div>
                            </div>
                        </div>

                             <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <div class="widget-content">
                                    <h6>Gurgaon Service Area</h6>
                                   
                                            <ul>
                                                <li><a href="website-design-company-gurgaon.php">Website Design company In Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-railway-road-gurgaon.php">Website Design company In Railway Road Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-mg-road-gurgaon.php">Website Design company In MG Road Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-shona-road-gurgaon.php">Website Design company In  Shona Road Gurgaon</a></li>
                                                
                                                <li><a href="https://www.bizzeonline.com/website-design-company-sikanderpur-gurgaon.php">Website Design company In Sikanderpur Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-golf-course-road-gurgaon.php">Website Design company In Golf Course Road Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-dlf-cyber-city-gurgaon.php">Website Design company In DLF Cyber City Gurgaon</a></li>
                                                <li><a href="https://www.bizzeonline.com/website-design-company-udyog-vihar-gurgaon.php">Website Design company In Udyog Vihar Gurgaon</a></li>
                                            
                                            <li><a href="https://bizzeonline.com/website-designer-near-me.php">Website Designer Near Me</a></li>
                                            </ul>
                                        
                                </div>
                            </div>
                        </div>



                    </div>

                </div>
            </div>

            <!-- Footer Bottom -->
            <div class="footer-bottom">
                <div class="auto-container">
                    <div class="inner clearfix">
                        <div class="copyright">&copy; copyright 2020-21 | Website Design & Developed By <i class="fa fa-heart fa-1x" style="color:red"></i><a href="https://www.bizzeonline.com/"> Bizzeonline</a></div>
                    </div>
                </div>
            </div>

        </footer>

    </div>
    <!--End pagewrapper-->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>



    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/TweenMax.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.fancybox.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/mixitup.js"></script>
    <script src="js/knob.js"></script>
    <script src="js/validate.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jQuery.style.switcher.min.js"></script>
    
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/custom-script.js"></script>

  
    <script src="js/color-switcher.js"></script>
</body>

</html>