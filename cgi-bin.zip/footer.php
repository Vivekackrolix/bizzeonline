 <!-- Main Footer -->
        <footer class="main-footer">
            <div class="auto-container">
                <!--Widgets Section-->
                <div class="widgets-section">
                    <div class="row clearfix">

                                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget logo-widget">
                                <div class="widget-content">
                                    <div class="logo">
                                        <a href="index.php"><img id="fLogo" src="images/bizzeonline footer logo.png" alt="bizzeonline website design company footer logo" title="bizzeonline website design company footer logo" /></a>
                                    </div>
                                    <div class="text">Welcome to our website bizzeonline.com website design & development company in gurgaon.</div>
                                    <ul class="social-links clearfix">
                                        <li><a href="https://www.facebook.com/bizzeonline/"target="_blank"><span class="fab fa-facebook-square"></span></a></li>
                                        <li><a href="https://twitter.com/bizzeonline"target="_blank"><span class="fab fa-twitter"></span></a></li>
                                        <li><a href="https://www.instagram.com/bizzeonline/"target="_blank"><span class="fab fa-instagram"></span></a></li>
                                        <li><a href="https://in.pinterest.com/Bizzeonline/website-designing-company/" target="_blank"><span class="fab fa-pinterest-p"></span></a></li>
                                    </ul>
                                     <ul class="Google Listing">    
                                     <style>
                                         .my-hover{
                                             color:#999b9f;
                                         }
                                         .my-hover:hover{
                                                 color: #ffffff;
                                                text-decoration: underline;
                                                -webkit-text-decoration-color: var(--thm-base);
                                                text-decoration-color: var(--thm-base);
                                         }
                                     </style>
                                        <a class="my-hover" href="https://www.google.com/search?q=Bizzeonline%7C%20Website%20Design%20Company%20Gurgaon%20%7C%20Website%20Development%20Company%20In%20Gurgaon%20%7C%20Digital%20Marketing%20Company%20%7C%20SEO%20Company%20Gurgaon%20%7C%20Website%20Designer%20%7C%20Website%20Developer%20In%20Gurgaon&rlz=1C1CHBD_enIN861IN861&oq=Bizzeonline%7C+Website+Design+Company+Gurgaon+%7C+Website+Development+Company+In+Gurgaon+%7C+Digital+Marketing+Company+%7C+SEO+Company+Gurgaon+%7C+Website+Designer+%7C+Website+Developer+In+Gurgaon&aqs=chrome..69i57j69i60l3.1214j0j1&sourceid=chrome&ie=UTF-8&tbs=lrf:!1m4!1u3!2m2!3m1!1e1!1m4!1u2!2m2!2m1!1e1!2m1!1e2!2m1!1e3!3sIAE,lf:1,lf_ui:14&tbm=lcl&rflfq=1&num=10&rldimm=16790593111490283991&lqi=CrgBQml6emVvbmxpbmV8IFdlYnNpdGUgRGVzaWduIENvbXBhbnkgR3VyZ2FvbiB8IFdlYnNpdGUgRGV2ZWxvcG1lbnQgQ29tcGFueSBJbiBHdXJnYW9uIHwgRGlnaXRhbCBNYXJrZXRpbmcgQ29tcGFueSB8IFNFTyBDb21wYW55IEd1cmdhb24gfCBXZWJzaXRlIERlc2lnbmVyIHwgV2Vic2l0ZSBEZXZlbG9wZXIgSW4gR3VyZ2FvbkjGq4fHhbaAgAhahAIQABABEAIQAxAEEAUQBhAHEAoQCxAMEA0QDhAPEBAQERASEBMQFBAVGAAYARgCGAMYBBgFGAYYBxgIGAkYChgLGAwYDRgOGA8YEBgRGBIYExgUGBUirQFiaXp6ZW9ubGluZSB3ZWJzaXRlIGRlc2lnbiBjb21wYW55IGd1cmdhb24gd2Vic2l0ZSBkZXZlbG9wbWVudCBjb21wYW55IGluIGd1cmdhb24gZGlnaXRhbCBtYXJrZXRpbmcgY29tcGFueSBzZW8gY29tcGFueSBndXJnYW9uIHdlYnNpdGUgZGVzaWduZXIgd2Vic2l0ZSBkZXZlbG9wZXIgaW4gZ3VyZ2FvbpIBEHdlYnNpdGVfZGVzaWduZXKaASRDaGREU1VoTk1HOW5TMFZKUTBGblNVUmhjRzk1Tm5WUlJSQUI&ved=2ahUKEwjIu4Wgx7rzAhVZXSsKHQkaBpoQvS56BAgTEEY&rlst=f#rlfi=hd:;si:16790593111490283991,l,CrgBQml6emVvbmxpbmV8IFdlYnNpdGUgRGVzaWduIENvbXBhbnkgR3VyZ2FvbiB8IFdlYnNpdGUgRGV2ZWxvcG1lbnQgQ29tcGFueSBJbiBHdXJnYW9uIHwgRGlnaXRhbCBNYXJrZXRpbmcgQ29tcGFueSB8IFNFTyBDb21wYW55IEd1cmdhb24gfCBXZWJzaXRlIERlc2lnbmVyIHwgV2Vic2l0ZSBEZXZlbG9wZXIgSW4gR3VyZ2FvbkjGq4fHhbaAgAhahAIQABABEAIQAxAEEAUQBhAHEAoQCxAMEA0QDhAPEBAQERASEBMQFBAVGAAYARgCGAMYBBgFGAYYBxgIGAkYChgLGAwYDRgOGA8YEBgRGBIYExgUGBUirQFiaXp6ZW9ubGluZSB3ZWJzaXRlIGRlc2lnbiBjb21wYW55IGd1cmdhb24gd2Vic2l0ZSBkZXZlbG9wbWVudCBjb21wYW55IGluIGd1cmdhb24gZGlnaXRhbCBtYXJrZXRpbmcgY29tcGFueSBzZW8gY29tcGFueSBndXJnYW9uIHdlYnNpdGUgZGVzaWduZXIgd2Vic2l0ZSBkZXZlbG9wZXIgaW4gZ3VyZ2FvbpIBEHdlYnNpdGVfZGVzaWduZXKaASRDaGREU1VoTk1HOW5TMFZKUTBGblNVUmhjRzk1Tm5WUlJSQUI;mv:[[28.509721199999998,77.10022479999999],[28.3389086,76.92998779999999]];tbs:lrf:!1m4!1u3!2m2!3m1!1e1!1m4!1u2!2m2!2m1!1e1!2m1!1e2!2m1!1e3!3sIAE,lf:1,lf_ui:14"target="_blank"> Google Business Listing</a>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget links-widget">
                                <div class="widget-content">
                                    <h6>Explore</h6>
                                    <div class="row clearfix">
                                        <div class="col-md-6 col-sm-12">
                                            <ul>
                                                <li><a href="index.php" title="Home">Home</a></li>
                                                <li><a href="about.php" title="About Website Design Company">About</a></li>
                                                <li><a href="team.php" title="Bizzeonline Website Design Company team">Meet Our Team</a></li>
                                                <li><a href="portfolio.php" title="Bizzeonline Website Design Company portfolio">Our Portfolio</a></li>
                                                
                                                <li><a href="contact.php" title="Contact Bizzeonline Website Design Company">Contact</a></li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <ul>
                                                <li><a href="career.php" title="Carrer in Website Design Company">Career</a></li>
                                                <li><a href="#" title="Looking For Website Design Company Support">Support</a></li>
                                                <li><a href="#" title="Bizzeonline Website Design Company Policy">Privacy Policy</a></li>
                                                <li><a href="#" title="Website Design Company terms and use">Terms of Use</a></li>
                                                <li><a href="contact.php" title="call or enquire Website Design Company">Help</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget info-widget">
                                <div class="widget-content">
                                    <h6>Contact</h6>
                                    <ul class="contact-info">
                                        <li class="address"><span class="icon flaticon-pin-1"></span> 359, Sector 28, Golf Course Road<br>Gurgaon -122001 Haryana India</li>
                                        <li><span class="icon flaticon-call"></span><a href="tel:+91-8104330050">+91-8104330050</a></li>
                                        <li><span class="icon flaticon-email-2"></span> <a href="mailto:subrata@bizzeonline.com">subrata@bizzeonline.com</a></li>
                                         
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!--Column-->
                        <div class="column col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="footer-widget newsletter-widget">
                                <div class="widget-content">
                                    <h6>Newsletter</h6>
                                    <div class="newsletter-form">
                                        <form method="post" action="">
                                            <div class="form-group clearfix">
                                                <input type="email" name="email" value="" placeholder="Email Address"
                                                    required="">
                                                <button type="submit" class="theme-btn"><span
                                                        class="fa fa-envelope"></span></button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="text">Sign up for our latest news & articles. We won’t give you spam
                                        mails.</div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

            <!-- Footer Bottom -->
            <div class="footer-bottom">
                <div class="auto-container">
                    <div class="inner clearfix">
                        <div class="copyright">&copy; copyright 2020-21 | Website Design & Developed By <i class="fa fa-heart fa-1x" style="color:red"></i><a href="https://www.bizzeonline.com/"> Bizzeonline</a></div>
                    </div>
                </div>
            </div>

        </footer>

    </div>
    <!--End pagewrapper-->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>



    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/TweenMax.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.fancybox.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/mixitup.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jQuery.style.switcher.min.js"></script>

    </script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/custom-script.js"></script>

    <!--<script src="js/lang.js"></script>-->

    <script src="js/color-switcher.js"></script>
</body>

</html>