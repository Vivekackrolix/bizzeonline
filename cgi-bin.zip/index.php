<?php
// Define variables for SEO

$pageTitle = 'BizzeOnline Website Design Company Gurgaon | SEO Services';

$pageDescription = 'BizzeOnline is Website Design and Development Company In Gurgaon, SEO Services Company Gurgaon with team of website designer and developer.';

$pagekeywords = 'BizzeOnline, www.Bizzeonline.com, Website Design Company, Website Development Company, Website Design Company Gurgaon India, Best Website Design Company Gurgaon India, Website Design Company Gurgaon, Best Website Design Company gurgaon, Top Website Design Company, Website Designer In Gurgaon, Web Design Company In Gurgaon, Web Development Company Gurgaon,Software Development Company, Software Development Company In Gurgaon, Software Development Company Gurgaon, Best Software Development Company, Mobile App Development Company Gurgaon, App Development Company, Android App Development Company, Digital marketing Company, Digital Marketing Company Gurgaon, Healthcare Website Design company, Educational Website Design company, Institutional Website Design company, School Website Design company, Colleges Website Design company, Real Estate Website Design company, Construction Website Design company, Manpower Website Design company, Job Consultant Website Design company, Hospitality Website Design company, Tourism Website Design company, Tour and Travel Website Design company, Clothing Website Design company, Fashion and Apparel Website Design company, Industrial Website Design company, Automation Website Design company, Manufacturing Website Design company, Packers and Movers Website Design company, Logistics Website Design company, Transport Website Design company, Website Design Company Golf Course Road, Website Design Company MG road, Website design Company Railway Road, Website Designer Near Me, Website developer Near Me, Website Designer Gurgaon, Website Developer Gurgaon, Top website Designer Gurgaon, seo company in gurgaon, seo services in gurgaon, seo services company in gurgaon, seo service company in gurgao, search engine optimisation company,search engine optimisation company gurgaon, search engine optimisation services gurgaon,search engine optimisation services, affordable website design company, affordable website design near me, best company website design, best ecommerce website design company, best it company website design, best web design company in gurgaon,best web design company in gurgaon, best web design company in india, best web designing company in gurgaon, best web designing company in gurgaon, best web development company in gurgaon, best web development company in gurgaon, best website design company, best website designer near me, best website designers near me, best website designing company in gurgaon, best website designing company in gurgaon, best website designing company in india, best website developer near me, best website development company in gurgaon, best website development company in gurgaon, business website design, business website design company, cheap web designer near me, cheap website design near me, corporate website design company, custom website design company, custom website design company, custom website design near me, easy website design, ecommerce development company in gurgaon, ecommerce development company in gurgaon, ecommerce website design company, ecommerce website design company, ecommerce website design company delhi, ecommerce website design gurgaon, ecommerce website design gurgaon, ecommerce website design near me, ecommerce website designer near me, ecommerce website development company in gurgaon, ecommerce website development company in gurgaon, freelance website designer in gurgaon, freelance website designer in gurgaon, professional website design company, professional website designer near me, seo website design company, small business website design near me, small website design company, top 10 website developer in gurgaon,top 10 website developer in gurgaon, top web development companies in gurgaon, top website designer in gurgaon, top website designer in gurgaon, top website developer in gurgaon, top website developer in gurgaon, web design company,web design company in india, web design company website,web design gurgaon, web design gurgaon, web designer company near me, web designing company in gurgaon, web designing company in gurgaon, web developer in gurgaon, web developer in gurgaon, web development company in gurgaon, web development company in gurgaon, web development gurgaon, website creation near me, website design, website design, website design & development company, website design and development, website design and development company, website design and development company in bangalore, website design and development company in delhi, website design and development company in gurgaon, website design and development company in gurgaon, website design and development company in india, website design and development company in mumbai, website design and development company in pune, website design and hosting, website design and maintenance companies near me, website design companies near me, website design cost, website design delhi, website design for company, website design gurgaon, website design gurgaon, website design ideas, website design india, website design near me, website design online, website design packages, website design services,website designer, website designer and developer, website designer cheap, website designer gurgaon, website designer gurgaon, website designer in gurgaon, website designer in gurgaon, website designer near me, website designer near me, website designer online, website designer online free, website designer reviews, website designer uk, website designing company gurugram, website designing company in delhi, website designing company in gurgaon, website designing company in gurgaon, website designing company in gurugram, website designing company in india, website developer gurgaon, website developer gurgaon, website developer in gurgaon, website developer in gurgaon, website developer near me, website development company, website development company in delhi, website development company in gurgaon, website development company in gurgaon, website development company in gurugram, website development company in gurugram, website development company in india, website development in gurgaon, website development in gurgaon, website maker in gurgaon, website maker in gurgaon, wordpress designer near me, wordpress web designer near me, wordpress website design company, wordpress website design near me, wordpress website designer near me, web development company, website development company, web design company, website design company, website company, website designer, website developer, website developer near me';

$canonicalurl ='https://www.bizzeonline.com/index.php';

$ogtitle = 'BizzeOnline | Website Design Company Gurgaon | SEO Company Gurgaon';


$ogdescription= 'Website Design Company Gurgaon: BizzeOnline is one of the Best Website Design Development Company Gurgaon India. Ranked among the Top website development company gurgaon';

$ogurl ='https://www.bizzeonline.com/index.php';

$ogsitename ='BizzeOnline | Website Design Company Gurgaon | SEO Company Gurgaon';

$ogimageurl ='https://www.bizzeonline.com/images/resource/bizzeonline desktop.png';

$ogimagesecureurl = 'https://www.bizzeonline.com/images/resource/bizzeonline desktop.png';

$twdescription = 'Website Design Company Gurgaon: BizzeOnline is one of the Best Website Design Development Company Gurgaon India. Ranked among the Top website Design company gurgaon';

$twtitle = 'BizzeOnline | Website Design Company Gurgaon | SEO Company Gurgaon';

$twimageurl = 'https://www.bizzeonline.com/images/resource/bizzeonline desktop.png';

$schemaidname = ' https:\/\/www.bizzeonline.com/index.php\/#breadcrumb,';

$listid = 'https:\/\/www.bizzeonline.com/index.php\/';

$listidname = 'Website Design Company Gurgaon: BizzeOnline is one of the Best Website Design Development Company Gurgaon India. Ranked among the Top website Design company gurgaon';

$templatename = 'page-template page-template-template-parts page-template-website-design-company-gurgaon page-template-software-development-gurgaon page-template-template-parts-seo-serch-engine-optimisation-company-gurgaon';

?>

<?php
include('header.php');
?>
<!-- Banner Section -->
        <section class="banner-section banner-one">

            <div class="left-based-text">
                <div class="base-inner">
                    <div class="hours">
                        <ul class="clearfix">
                            <li><span>mon - sat</span></li>
                            <li><span>9am - 7pm</span></li>
                        </ul>
                    </div>
                    <div class="social-links">
                        <ul class="clearfix">
                            <li><a href="#"><span>Twitter</span></a></li>
                            <li><a href="https://www.facebook.com/bizzeonline/"><span>Facebook</span></a></li>
                            <li><a href="#"><span>Youtube</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="banner-carousel owl-theme owl-carousel">
                <!-- Slide Item -->
                <div class="slide-item">
                    <div class="image-layer" style="background-image: url(images/main-slider/1.jpg);" alt="website design company in gurgaon " title="website design company in gurgaon "></div>
                    <div class="left-top-line"></div>
                    <div class="right-bottom-curve"></div>
                    <div class="right-top-curve"></div>
                    <div class="auto-container">
                        <div class="content-box">
                            <div class="content">
                                <div class="inner">
                                    <div class="sub-title">BizzeOnline</div>
                                    <h1 text color:orange; >Website Design & Development Company Gurgaon<br></h1>
                                    <h4 style="color:white;">We deliver promises</h4>
                                    <div class="link-box">
                                        <a class="theme-btn btn-style-one" href="about.php">
                                            <i class="btn-curve"></i>
                                            <span class="btn-title">Discover More</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Slide Item -->
                <div class="slide-item">
                    <div class="image-layer" style="background-image: url(images/main-slider/2.jpg);" alt="seo services company in gurgaon " title="seo company in gurgaon "></div>
                    <div class="left-top-line"></div>
                    <div class="right-bottom-curve"></div>
                    <div class="right-top-curve"></div>
                    <div class="auto-container">
                        <div class="content-box">
                            <div class="content">
                                <div class="inner">
                                    <div class="sub-title">BizzeOnline</div>
                                    <h1>Search Engine Optimisation company Gurgaon<br></h1>
                                    <h4 style="color:white;">Increase Your Brand Value</h4>
                                    <div class="link-box">
                                        <a class="theme-btn btn-style-one" href="about.php">
                                            <i class="btn-curve"></i>
                                            <span class="btn-title">Discover More</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!--End Banner Section -->
        <!----- pop up form --->
        
       

        
        <!---- end form --->

        <!--Services Section-->
        <section class="services-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Title Block-->
                    <div class="title-block col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="sec-title">
                                <h2>We Shape the Perfect <br>Solutions<span class="dot">.</span></h2>
                                <div class="lower-text">We are committed to providing our customers with exceptional
                                    service while offering our employees the best training.</div>
                            </div>
                        </div>
                    </div>
                    <!--Service Block-->
                    <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="bottom-curve"></div>
                            <div class="icon-box"><span class="flaticon-responsive"></span></div>
                            <h6><a href="website-design-company.php">Website <br>Design</a></h6>
                        </div>
                    </div>
                    <!--Service Block-->
                    <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft"
                        data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="bottom-curve"></div>
                            <div class="icon-box"><span class="flaticon-app-development"></span></div>
                            <h6><a href="mobile-app-development-company.php">Mobile App<br>Development</a></h6>
                        </div>
                    </div>
                    <!--Service Block-->
                    <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="bottom-curve"></div>
                            <div class="icon-box"><span class="flaticon-development"></span></div>
                            <h6><a href="software-development-company.php">Software<br>Development</a></h6>
                        </div>
                    </div>
                    <!--Service Block-->
                    <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft"
                        data-wow-delay="300ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="bottom-curve"></div>
                            <div class="icon-box"><span class="flaticon-digital-marketing"></span></div>
                            <h6><a href="digital-marketing-company.php">Digital <br>Marketing</a></h6>
                        </div>
                    </div>
                    <!--Service Block-->
                    <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft"
                        data-wow-delay="600ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="bottom-curve"></div>
                            <div class="icon-box"><span class="flaticon-computer"></span></div>
                            <h6><a href="ecommerce-services.php">eCommere <br>Development</a></h6>
                        </div>
                    </div>
                    <!--Service Block-->
                    <div class="service-block col-xl-3 col-lg-6 col-md-6 col-sm-12 wow fadeInLeft"
                        data-wow-delay="900ms" data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="bottom-curve"></div>
                            <div class="icon-box"><span class="flaticon-ui"></span></div>
                            <h6><a href="ui-designing.php">Ui/UX <br>designing</a></h6>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--About Section-->
        <section class="about-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Image Column-->
                    <div class="image-column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="image-block wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms"><img
                                    src="images/resource/featured-image-1.jpg" alt="top website design company in gurgaon"></div>
                            <div class="image-block wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms"><img
                                    src="images/resource/office.png" alt="website design company offices near me"></div>
                        </div>
                    </div>
                    <!--Text Column-->
                    <div class="text-column col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="sec-title">
                                <h2>India's Most Trusted<br><span class="dot">Branding & Marketing Company.</span></h2>
                                <div class="lower-text">We Work With Our Customers For Their Sustained Success</div>
                            </div>
                            <div class="text">
                                <p>Bizzeonline is a premier <a href="https://www.bizzeonline.com/website-design-company.php" title="website design company">website design</a> and development company in Gurgaon India with seo service in gurgaon. We have a professional team of website designer and developer. We have been providing solutions to clients across the world for over 7 years and boast of our extensive experience on website designing and mobile app development projects. With over 5100 website design and mobile application projects executed, we live and breathe the web.</p>
                            </div>
                            <div class="text clearfix">
                                <ul>
                                    <li>Strategic Business Consulting</li>
                                    <li>ROI Focussed Digital Campaign</li>
                                    <li>Creative UI/UX Designing</li>
                                </ul>
                                <div class="since"><span class="txt">Since <br>2008</span></div>
                            </div>
                            <div class="link-box">
                                <a class="theme-btn btn-style-one" href="about.php">
                                    <i class="btn-curve"></i>
                                    <span class="btn-title">Discover More</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--Live Section-->
        <section class="live-section">
            <div class="auto-container">
                <div class="sec-title centered">
                    <h2>Experience us live <span class="dot">.</span></h2>
                </div>
                <div class="main-image-box">
                    <div class="image-layer" style="background-image: url(images/resource/featured-image-3.jpg);"></div>
                    <div class="inner clearfix">
                        <div class="round-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="round-inner">
                                <div class="vid-link">
                                    <a href="#" class="lightbox-image">
                                        <div class="icon"><span class="flaticon-play-button-1"></span><i
                                                class="ripple"></i></div>
                                    </a>
                                </div>
                                <div class="title">
                                    <h3>agency that gets <br>excited about</h3>
                                </div>
                                <div class="more-link"><a href="about.php">Read More</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!--We DO Section-->
        <section class="we-do-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Left Column-->
                    <div class="left-col col-lg-6 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="sec-title">
                                <h2>We Help Brand To Achieve Their<br>Business Outcomes <span class="dot">.</span></h2>
                            </div>
                            <div class="featured-block clearfix">
                                <div class="image"><img src="images/resource/web design company gurgaon.png" alt="web design company gurgaon"></div>
                                <div class="text">We have worked with global brands and innovative startups, bringing together diverse teams of talented people to change the way companies do business.</div>
                            </div>
                            <div class="progress-box">
                                <div class="bar-title">Business Growth</div>
                                <div class="bar">
                                    <div class="bar-inner count-bar" data-percent="70%">
                                        <div class="count-box">
                                            <span class="count-text" data-stop="90" data-speed="1500">0</span>%
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Right Column-->
                    <div class="right-col col-lg-6 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="faq-box">
                                <ul class="accordion-box clearfix">
                                    <!--Block-->
                                    <li class="accordion block active-block">
                                        <div class="acc-btn active"><span class="count">1.</span> Product Engineering</div>
                                        <div class="acc-content current">
                                            <div class="content">
                                                <div class="text">Realize your vision with a tailored software, delivered on-time and within your budget.</div>
                                            </div>
                                        </div>
                                    </li>

                                    <!--Block-->
                                    <li class="accordion block">
                                        <div class="acc-btn"><span class="count">2.</span> Smart Teams
                                        </div>
                                        <div class="acc-content">
                                            <div class="content">
                                                <div class="text">Boost your development with our cross-functional experts</div>
                                            </div>
                                        </div>
                                    </li>

                                    <!--Block-->
                                    <li class="accordion block">
                                        <div class="acc-btn"><span class="count">3.</span>Enterprise Solutions</div>
                                        <div class="acc-content">
                                            <div class="content">
                                                <div class="text">Create efficiencies at a large scale delivering hyper growth.</div>
                                            </div>
                                        </div>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Gallery Section -->
        <section class="gallery-section">
            <div class="auto-container">
                <!--MixitUp Galery-->
                <div class="mixitup-gallery">
                    <div class="upper-row clearfix">
                        <div class="sec-title">
                            <h2>work showcase <span class="dot">.</span></h2>
                        </div>
                        <!--Filter-->
                        <div class="filters clearfix">
                            <ul class="filter-tabs filter-btns clearfix">
                                <li class="active filter" data-role="button" data-filter="all">All<sup>[6]</sup></li>
                                <li class="filter" data-role="button" data-filter=".website">Website<sup>[3]</sup>
                                </li>
                                <li class="filter" data-role="button" data-filter=".ecommerce">
                                    Ecommerce<sup>[3]</sup></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="filter-list row">
                        <!-- Gallery Item -->
                        <div class="gallery-item  website col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <figure class="image"><img src="images/gallery/healthcare training institute website design company gurgaon.PNG" alt="healthcare training institute website design company gurgaon" title="healthcare website design company gurgaon"></figure>
                                <a href="images/gallery/healthcare training institute website design company gurgaon.PNG" class="lightbox-image overlay-box"
                                    data-fancybox="gallery" title="healthcare website design company" alt="healthcare website design company"></a>
                                <div class="cap-box">
                                    <div class="cap-inner">
                                        <div class="cat"><span>Institute Website Design</span></div>
                                        <div class="title">
                                            <h5><a href="portfolio.php">Healthcare Insitute</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Gallery Item -->
                        <div class="gallery-item mobile-app col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <figure class="image"><img src="images/gallery/online shoping clothes ecommerce website design company gurgaon.PNG" alt="online shoping clothes ecommerce website design company gurgaon" title="ecommerce website design company gurgaon"></figure>
                                <a href="images/gallery/online shoping clothes ecommerce website design company gurgaon.PNG" class="lightbox-image overlay-box"
                                    data-fancybox="gallery" title="ecommerce website design company gurgaon" alt="ecommerce website design company gurgaon"></a>
                                <div class="cap-box">
                                    <div class="cap-inner">
                                        <div class="cat"><span>Ecommerce Website Design</span></div>
                                        <div class="title">
                                            <h5><a href="portfolio.php">Fashion and Apparel Website Experience</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Gallery Item -->
                        <div class="gallery-item ecommerce col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <figure class="image"><img src="images/gallery/interior designing website design company gurgaon.PNG" alt="interior designing website design company gurgaon" title="interior website design company gurgaon"></figure>
                                <a href="images/gallery/interior designing website design company gurgaon.PNG" class="lightbox-image overlay-box"
                                    data-fancybox="gallery" title="interior website design company" alt="ecommerce website design company"></a>
                                <div class="cap-box">
                                    <div class="cap-inner">
                                        <div class="cat"><span>Interior website Design</span></div>
                                        <div class="title">
                                            <h5><a href="portfolio.php">Interior & Architure Website</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Gallery Item -->
                        <div class="gallery-item software col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <figure class="image"><img src="images/gallery/online machine selling ecommerce website design company gurgaon.PNG" alt="industrial products ecommerce website design" title="industrial products ecommerce website design company"></figure>
                                <a href="images/gallery/online machine selling ecommerce website design company gurgaon.PNG" class="lightbox-image overlay-box"
                                    data-fancybox="gallery" alt="machine selling ecommerce website design" title="machine selling ecommerce website design company"></a>
                                <div class="cap-box">
                                    <div class="cap-inner">
                                        <div class="cat"><span>Ecommerce Website</span></div>
                                        <div class="title">
                                            <h5><a href="portfolio.php">Industrial Products Ecommerce Website</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Gallery Item -->
                        <div
                            class="gallery-item mix all branding illustration photography web-design col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <figure class="image"><img src="images/gallery/industrial automation website design company gurgaon.PNG" alt="industrial automation website design company gurgaon" title="automation website design company gurgaon"></figure>
                                <a href="images/gallery/industrial automation website design company gurgaon.PNG" class="lightbox-image overlay-box"
                                    data-fancybox="gallery" alt="industrial automation website design company gurgaon" title="automation website design company gurgaon"></a>
                                <div class="cap-box">
                                    <div class="cap-inner">
                                        <div class="cat"><span>Industrial & Automation</span></div>
                                        <div class="title">
                                            <h5><a href="portfolio.php">Industrial Website Design</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Gallery Item -->
                        <div class="gallery-item mix all illustration photography col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <figure class="image"><img src="images/gallery/online beauty products ecommerce website design company gurgaon.PNG" alt="online beauty products ecommerce website design company gurgaon" title="online beauty products ecommerce website design company gurgaon"></figure>
                                <a href="images/gallery/online beauty products ecommerce website design company gurgaon.PNG" class="lightbox-image overlay-box"
                                    data-fancybox="gallery" alt="online beauty products ecommerce website design company gurgaon" title="online beauty products ecommerce website design company gurgaon"></a>
                                <div class="cap-box">
                                    <div class="cap-inner">
                                        <div class="cat"><span>Ecommerce Website</span></div>
                                        <div class="title">
                                            <h5><a href="portfolio.php">Beauty Products Website Design</a></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </section>

        <!-- Funfacts Section -->
        <section class="facts-section jarallax" data-jarallax data-speed="0.3" data-imgPosition="50% 80%">
            <!-- <div class="image-layer" style="background-image: url(images/background/image-1.jpg);"></div> -->
            <img src="images/background/image-1.jpg" class="jarallax-img" alt="website designer in gurgaon" title="website designer in gurgaon" >
            <div class="auto-container">
                <div class="inner-container">

                    <!-- Fact Counter -->
                    <div class="fact-counter">
                        <div class="row clearfix">

                            <!--Column-->
                            <div class="column counter-column col-lg-3 col-md-6 col-sm-12">
                                <div class="inner">
                                    <div class="content">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="4000" data-stop="8705">0</span>
                                        </div>
                                        <div class="counter-title">Projects Completed</div>
                                    </div>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column counter-column col-lg-3 col-md-6 col-sm-12">
                                <div class="inner">
                                    <div class="content">
                                        <div class="count-outer count-box alternate">
                                            <span class="count-text" data-speed="3000" data-stop="480">0</span>
                                        </div>
                                        <div class="counter-title">Active clients</div>
                                    </div>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column counter-column col-lg-3 col-md-6 col-sm-12">
                                <div class="inner">
                                    <div class="content">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="626">0</span>
                                        </div>
                                        <div class="counter-title">cups of coffee</div>
                                    </div>
                                </div>
                            </div>

                            <!--Column-->
                            <div class="column counter-column col-lg-3 col-md-6 col-sm-12">
                                <div class="inner">
                                    <div class="content">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="4000" data-stop="9704">0</span>
                                        </div>
                                        <div class="counter-title">happy clients</div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- End Funfacts Section -->

        <!-- Trusted Section -->
        <section class="trusted-section">
            <div class="auto-container">
                <div class="outer-container">
                    <div class="row clearfix">
                        <div class="left-col col-xl-5 col-lg-6 col-md-12 col-sm-12">
                            <div class="inner">
                                <div class="col-header">
                                    <div class="header-inner">
                                        <span>We’re Committed To Deliver High Quality Projects .</span>
                                    </div>
                                </div>
                                <div class="features">
                                    <div class="feature">
                                        <div class="count"><span>01</span></div>
                                        <h5>TOTAL DESIGN FREEDOM FOR EVERYONE</h5>
                                        <div class="sub-text">core features</div>
                                    </div>
                                    <div class="feature">
                                        <div class="count"><span>02</span></div>
                                        <h5>BASIC RULES OF RUNNING WEB AGENCY</h5>
                                        <div class="sub-text">core features</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="right-col col-xl-7 col-lg-6 col-md-12 col-sm-12">
                            <div class="inner">
                                <div class="sec-title">
                                    <h2>We’re trusted by more <br>than 6260 clients<span class="dot">.</span></h2>
                                    <div class="lower-text">Our simple reason to exist is to help you become Successful. It’s as simple as that. So when we Develop Website and Mobile applications for you, we do it with keeping that objective in mind - and we do it darn well. Our secret sauce for success is – we take pains in understanding what your Customers need from you and exceed their expectations. We are sure that would certainly delight you!</div>
                                </div>
                                <div class="featured-block-two clearfix">
                                    <div class="image"><img src="images/resource/website development company gurgaon.png" alt="website development company gurgaon near me" title="website development company gurgaon near me"></div>
                                    <div class="text">
                                        <ul>
                                            <li>Fixed Quotes</li>
                                            <li>Dedicated Teams</li>
                                            <li>Pay As You Go</li>
                                            <li>Staff Augmentation & Offshore Teams</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <section class="team-section no-padd-top">
            <div class="auto-container">
                <div class="sec-title centered">
                    <h2>Meet the expert team<span class="dot">.</span></h2>
                </div>
            </div>
            <div class="carousel-box">
                <div class="team-carousel owl-theme owl-carousel">
                   
                    <!--Team-->
                    <div class="team-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/team/Employee 1.png" alt="hire website develeloper in gurgaon" title="website develeloper in gurgaon"></a>
                              <!----  <ul class="social-links clearfix">
                                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                </ul>
                                ---->
                            </div>
                            <div class="lower-box">
                                <h5><a href="#">Sourabh Sharma</a></h5>
                                <div class="designation">Project Manager</div>
                            </div>
                        </div>
                    </div>

                    <!--Team-->
                    <div class="team-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/team/Employee 2.png" alt="web developer in gurgaon" title="web develeloper in gurgaon"></a>
                        <!---        <ul class="social-links clearfix">
                                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                </ul>
                                --->
                            </div>
                            <div class="lower-box">
                                <h5><a href="#">Mahi</a></h5>
                                <div class="designation">Business Development Manager</div>
                            </div>
                        </div>
                    </div>

                    <!--Team-->
                    <div class="team-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/team/Employee 3.png" alt="website developer in grugaon" title="website develeloper in gurgaon"></a>
                        <!---        <ul class="social-links clearfix">
                                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                </ul>
                                --->
                            </div>
                            <div class="lower-box">
                                <h5><a href="#">Poonam</a></h5>
                                <div class="designation">Software Developer</div>
                            </div>
                        </div>
                    </div>
                    <!--Team-->
                    <div class="team-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/team/Employee 4.png" alt="frontend developer in gurgaon" title="frontend website develeloper in gurgaon"></a>
                        <!---        <ul class="social-links clearfix">
                                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                </ul>
                                --->
                            </div>
                            <div class="lower-box">
                                <h5><a href="#">Monika</a></h5>
                                <div class="designation">Sr. Developer</div>
                            </div>
                        </div>
                    </div>

                    <!--Team-->
                    <div class="team-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/team/Employee 5.png" alt="backend developer in gurgaon" title="backend website develeloper in gurgaon"></a>
                        <!---        <ul class="social-links clearfix">
                                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                </ul>
                                --->
                            </div>
                            <div class="lower-box">
                                <h5><a href="#">Ravi</a></h5>
                                <div class="designation">Graphic Designer</div>
                            </div>
                        </div>
                    </div>

                    <!--Team-->
                    <div class="team-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/team/Employee 6.png" alt="php developer in grugaon" title="php website develeloper in gurgaon"></a>
                          <!---      <ul class="social-links clearfix">
                                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                </ul>
                                --->
                            </div>
                            <div class="lower-box">
                                <h5><a href="#">Aman</a></h5>
                                <div class="designation">Digital Marketing Manager</div>
                            </div>
                        </div>
                    </div>

                    <!--Team-->
                    <div class="team-block">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="about.php"><img src="images/team/Employee 7.png" alt="ecommerce website developer in gurgaon" title="ecommerce website develeloper in gurgaon"></a>
                        <!---        <ul class="social-links clearfix">
                                    <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                    <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                    <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                    <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                </ul>
                                --->
                            </div>
                            <div class="lower-box">
                                <h5><a href="#">Akshay</a></h5>
                                <div class="designation">UI/UX Designer</div>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </section>

        <!-- Parallax Section -->
        <section class="parallax-section jarallax" data-jarallax data-speed="0.3" data-imgPosition="50% 80%">
            <!-- <div class="image-layer" style="background-image: url(images/background/image-2.jpg);"></div> -->
            <img src="images/background/image-2.jpg" alt="best website design company in gurgaon india" title="best website design company in gurgaon india" class="jarallax-img">
            <div class="auto-container">
                <div class="content-box">
                    <div class="icon-box"><span class="flaticon-app-development"></span></div>
                    <h2>Great things in business are never done by one person. <span>They’re done by a team of
                            people.</span></h2>
                </div>
            </div>
        </section>
        <!-- End Funfacts Section -->

        <!--Sponsors Section-->
        <section class="sponsors-section">
            <div class="sponsors-outer">
                <!--Sponsors-->
                <div class="auto-container">
                    <!--Sponsors Carousel-->
                    <div class="sponsors-carousel owl-theme owl-carousel">
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 1.png" alt="web design near me" title="web designer near me"></a></figure>
                        </div>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 2.png" alt="web development company near me" title="web development company near me"></a></figure>
                        </div>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 3.png" alt="web developer near me" title="web developer near me"></a></figure>
                        </div>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 4.png" alt="professional website design company gurgaon" title="professional website design company gurgaon"></a></figure>
                        </div>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 5.png" alt="creative website design company gurgaon" title="creative website design company gurgaon"></a></figure>
                        </div>
                         <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 1.png" alt="expert website design company gurgaon" title="expert website design company gurgaon"></a></figure>
                        </div>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 2.png" alt="secure website design company gurgaon" title="secure website design company gurgaon"></a></figure>
                        </div>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 3.png" alt="best website designing company" title="best website designing company gurgaon"></a></figure>
                        </div>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 4.png" alt="website design services in gurgaon" title="website design services gurgaon"></a></figure>
                        </div>
                        <div class="slide-item">
                            <figure class="image-box"><a href="#"><img src="images/clients/client 5.png" alt="website design company in gurugram" title="professional website design company gurugram"></a></figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--Agency Section-->
        <section class="agency-section">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Left Column-->
                    <div class="left-col col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="sec-title">
                                <h2>Best design Agency <br>solutions <span class="dot">.</span></h2>
                            </div>

                            <!--Default Tabs-->
                            <div class="default-tabs tabs-box">

                                <!--Tab Btns-->
                                <ul class="tab-btns tab-buttons clearfix">
                                    <li data-tab="#tab-1" class="tab-btn active-btn"><span>Our Mission</span></li>
                                    <li data-tab="#tab-2" class="tab-btn"><span>Our Vision</span></li>
                                    <li data-tab="#tab-3" class="tab-btn"><span>Our Values</span></li>
                                </ul>

                                <!--Tabs Container-->
                                <div class="tabs-content">

                                    <!--Tab-->
                                    <div class="tab active-tab" id="tab-1">
                                        <div class="content">
                                            <div class="text">To Deliver Business Focused, “Offshore IT Solutions for SMBs” across the globe, offering Services like Web Design, Web Development, Mobile App Development, Php Development, RoR Development, E-commerce development, Agile application development, Cloud Consulting services and Cloud solutions.</div>
                                        </div>
                                    </div>

                                    <!--Tab-->
                                    <div class="tab" id="tab-2">
                                        <div class="content">
                                            <div class="text">We aspire to be the world’s best IT Solutions Partner, through technology leadership, innovation and a world class work force.</div>
                                        </div>
                                    </div>

                                    <!--Tab-->
                                    <div class="tab" id="tab-3">
                                        <div class="content">
                                            <div class="text">
                                                <li>Committed to Customer Satisfaction</li>
                                                <li>A knowledge-driven company</li>
                                                <li>Building solutions that create rewarding results</li
                                                <li>Orchestration of ROI driven solutions</li>
                                                <li>Client centric strategies</li>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Right Column-->
                    <div class="right-col col-xl-6 col-lg-12 col-md-12 col-sm-12">
                        <div class="inner">
                            <div class="text">BizzeOnline is a software engineering partner to 100+ organizations across the globe and has been helping them in making their software products more robust, teams more productive and processes more efficient. Our ability to look beyond technologies to deliver innovative solutions with scale and speed has been lauded by our clients as well as the tech community worldwide.</div>
                            <div class="featured-block-two clearfix">
                                <div class="image"><img src="images/resource/web development company gurgaon.png" alt="web development company gurgaon" title="web development company gurgaon"></div>
                                <div class="text">
                                    <ul>
                                        <li>Exceptionally talented professionals</li>
                                        <li>Passion-led engineering.</li>
                                        <li>Mature organizational processes.</li>
                                        <li>Transparency and collaboration.</li>
                                        <li>Dedicated R&D labs.</li>
                                        <li>Innovation focused.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- News Section -->
        <section class="news-section">
            <div class="auto-container">
                <div class="sec-title centered">
                    <h2>Latest news & articles<span class="dot">.</span></h2>
                </div>

                <div class="row clearfix">
                    <!--News Block-->
                    <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="0ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/resource/Web Design company.png" alt="web design company"></a>
                            </div>
                            <div class="lower-box">
                                <div class="post-meta">
                                    <ul class="clearfix">
                                        <li><span class="far fa-clock"></span> 20 Jan</li>
                                        <li><span class="far fa-user-circle"></span> Admin</li>
                                        <li><span class="far fa-comments"></span> 220 Comments</li>
                                    </ul>
                                </div>
                                <h5><a href="#">basic rules of running web agency business</a></h5>
                                <div class="text"></div>
                                <div class="link-box"><a class="theme-btn" href="#"><span
                                            class="flaticon-next-1"></span></a></div>
                            </div>
                        </div>
                    </div>
                    <!--News Block-->
                    <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/resource/Website Development Company.png" alt="website development company" title="website development company"></a>
                            </div>
                            <div class="lower-box">
                                <div class="post-meta">
                                    <ul class="clearfix">
                                        <li><span class="far fa-clock"></span> 21 Jan</li>
                                        <li><span class="far fa-user-circle"></span> Admin</li>
                                        <li><span class="far fa-comments"></span> 210 Comments</li>
                                    </ul>
                                </div>
                                <h5><a href="#">Delivering the best digital marketing</a></h5>
                                <div class="text"></div>
                                <div class="link-box"><a class="theme-btn" href="#"><span
                                            class="flaticon-next-1"></span></a></div>
                            </div>
                        </div>
                    </div>
                    <!--News Block-->
                    <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms"
                        data-wow-duration="1500ms">
                        <div class="inner-box">
                            <div class="image-box">
                                <a href="#"><img src="images/resource/Web design company india.png" alt="web design company gurgaon india"></a>
                            </div>
                            <div class="lower-box">
                                <div class="post-meta">
                                    <ul class="clearfix">
                                        <li><span class="far fa-clock"></span> 10 Jan</li>
                                        <li><span class="far fa-user-circle"></span> Admin</li>
                                        <li><span class="far fa-comments"></span> 110 Comments</li>
                                    </ul>
                                </div>
                                <h5><a href="#">Introducing the latest linoor features</a></h5>
                                <div class="text"></div>
                                <div class="link-box"><a class="theme-btn" href="#"><span
                                            class="flaticon-next-1"></span></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
                
        <!-- Call To Section -->
        <section class="call-to-section">
            <div class="auto-container">
                <div class="inner clearfix">
                    <div class="shape-1 wow slideInRight" data-wow-delay="0ms" data-wow-duration="1500ms"></div>
                    <div class="shape-2 wow fadeInDown" data-wow-delay="0ms" data-wow-duration="1500ms"></div>
                    <h2>Let's Get Your Project <br>Started!</h2>
                    <div class="link-box">
                        <a class="theme-btn btn-style-two" href="contact.php">
                            <i class="btn-curve"></i>
                            <span class="btn-title">Contact with us</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        
        
        
        
<!--         <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">-->
<!--  <div class="modal-dialog">-->
<!--    <div class="modal-content">-->
<!--      <div class="modal-header">-->
<!--        <p class="modal-title" id="myModalLabel">Wish You a Very Happy Diwali !</p>-->
<!--        <p> </p>-->
      
<!--      </div>-->
<!--     <div class="modal-body">-->
<!--        <img src="images/1st-gif.gif" alt="Happy Diwali" width="100%" height="400">-->
<!--      </div>-->
<!--       <div class="modal-footer">-->
<!--        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
      
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->





<?php
include('footer.php');
?>



<!-- Modal popup  -->
<!--<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body p-0">
          
              <button style="color: #E89C1A; padding: 0px 0px 0 0;
    font-size: 64px;
    z-index: 999;
    position: absolute;
    margin-left: 92%;" type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
                <img src="images/Gif.gif" alt="Happy Republic Day from Bizzeonline" width="100%" height="500">
         
           
      </div>
    </div>
  </div>
</div>-->



<script type="text/javascript">
    $(document).ready(function(){
        $("#exampleModal").modal('show');
    });
</script>
